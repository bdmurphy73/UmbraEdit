+++
name = "Scene 3.3: Footnotes"
parent = "6b3a7202-c067-42c2-adda-b163ab190223"
handle = "e904172f-897c-4436-8681-8487b9c979cf"
class = "NOVEL"
layout = "DOCUMENT"
textHash = "0000000000000000000000000000000000000000000000000000000000000000"
createdDate = "2026-11-12 08:00:00"
updatedDate = "2026-11-12 08:00:00"
+++
### Scene 3.3: Footnotes

@tag: Scene.Footnotes
@pov: Narrator

## Footnotes

UmbraEdit supports footnotes in your manuscript. You add a footnote reference in the text using `[footnote:id]`, and then define the footnote text using `%Footnote.id:`.

## Example

Thin spaces and thin non-breaking spaces are also supported from the Insert menu, and can be used to separate numbers from their units, like: 25 kg.[footnote:f4xr5]

%Footnote.f4xr5: Using a non-breaking space is the correct way to separate a number from its unit. This ensures that line wrapping does not split the two.

## How Footnotes Work

1. In your text, insert `[footnote:id]` where you want the footnote reference to appear. Replace `id` with a unique identifier.
2. Somewhere in your document (typically at the end), define the footnote using `%Footnote.id: Your footnote text here`.
3. When you export or build your manuscript, the footnote will appear at the bottom of the page with the corresponding reference number.

## Multiple Footnotes

You can have multiple footnotes in a single document:

The pocket watch was made of gold.[footnote:pw1] Alice had never seen a rabbit wear one before.[footnote:pw2]

%Footnote.pw1: Pocket watches were common accessories for gentlemen in the 19th century.
%Footnote.pw2: Anthropomorphic rabbits wearing clothing and accessories are a hallmark of Lewis Carroll's writing style.

## Footnotes in Exported Documents

When you build your manuscript for export (EPUB, DOCX, PDF, etc.), footnotes will be rendered according to the export format's conventions. In EPUB, they appear as endnotes or popup footnotes. In DOCX, they appear as Word footnotes.
