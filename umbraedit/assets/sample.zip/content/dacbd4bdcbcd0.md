+++
name = "Delete Me!"
parent = "ec2143e8-006d-47d1-920e-634bec082b41"
handle = "cdb109a9-2268-4e42-9ee8-9087a1f6795a"
class = "TRASH"
layout = "DOCUMENT"
textHash = "0000000000000000000000000000000000000000000000000000000000000000"
createdDate = "2026-11-12 08:00:00"
updatedDate = "2026-11-12 08:00:00"
+++
### Delete Me!

@tag: Trash.Delete

This is a document in the Trash root folder. Documents in the Trash are excluded from exports and word counts. You can move documents here when you want to remove them from your manuscript without permanently deleting them.

This document demonstrates that the Trash works — any content placed here will not appear in your exported manuscript.
