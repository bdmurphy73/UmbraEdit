+++
name = "Scene Template"
parent = "dffd5e8c-8e20-4455-ac69-ba0ef35f5f85"
handle = "dcc3f972-c445-464b-bf80-360bf280c1fc"
class = "TEMPLATE"
layout = "DOCUMENT"
textHash = "0000000000000000000000000000000000000000000000000000000000000000"
createdDate = "2026-11-12 08:00:00"
updatedDate = "2026-11-12 08:00:00"
+++
### Scene Template

@tag: Template.Scene
@pov:
@char:
@location:

## Scene Template

Use this template when creating new scene documents. Copy this file and replace the content with your own.

### Scene Structure

A scene is defined by a level three heading (###). Each paragraph is separated by a blank line.

### Required References

Fill in these references at the top of each new scene:
- @pov: — Point of View character
- @char: — Characters appearing in the scene
- @location: — Where the scene takes place
- @mention: — General mentions

### Formatting Reminders

- Use **bold** for emphasis
- Use _italic_ for thoughts or emphasis
- Use ~~strike-through~~ for deleted text
- Use [sup]superscript[/sup] and [sub]subscript[/sub] as needed
- Use bullet lists (* ) and ordered lists (#. ) for lists

### Tags

Always define a unique @tag: for each scene so you can reference it from other documents.
