+++
name = "Earth"
parent = "1a308cde-d73a-4a39-9d7a-2add296832c1"
handle = "35ec2150-b702-4d51-b143-f8101a57d4d3"
class = "WORLD"
layout = "NOTE"
textHash = "0000000000000000000000000000000000000000000000000000000000000000"
createdDate = "2026-11-12 08:00:00"
updatedDate = "2026-11-12 08:00:00"
+++
# Earth

@tag: Earth
@location: Space

%Short: Third planet from the sun.

Defining locations in your story can be very helpful. Here we have a tag called “Earth” which is a place in “Space”.

## Location Details

- **Type:** Planet
- **Star System:** Sol
- **Galaxy:** Milky Way
- **Dominant Species:** Humans
- **Notable Feature:** The only known planet with life

## Description

Earth is the primary location for most scenes in this example project. It is where Jane Smith and John Doe live and where most of the mystery unfolds.

Locations help you keep track of where your scenes take place. When you reference a location using `@location:`, UmbraEdit can help you ensure consistency across your manuscript.

## References

This location is referenced in:
- Scene 2.2: Tags and References (@location: Earth)
- Scene 4.2: Location References (@location: Earth)
